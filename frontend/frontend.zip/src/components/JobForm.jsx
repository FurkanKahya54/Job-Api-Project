// src/components/JobForm.jsx
import React, { useState } from "react";
import { TextField, Button, Box } from "@mui/material";
import { createOsJob, createCrawlJob, addJob } from "../api/jobs";

const JobForm = ({ onJobAdded }) => {
  const [command, setCommand] = useState("");
  const [url, setUrl] = useState("");

  // OS job ekleme
  const handleOsSubmit = async () => {
    if (!command) return;
    const result = await createOsJob(command);
    onJobAdded(result);
    setCommand("");
  };

  // Crawl job ekleme
  const handleCrawlSubmit = async () => {
    if (!url) return;
    const result = await createCrawlJob(url);
    onJobAdded(result);
    setUrl("");
  };

  // Genel job ekleme (opsiyonel)
  const handleGenericJob = async () => {
    const job = {
      type: command ? "os" : "crawl",
      command_or_url: command || url
    };
    const result = await addJob(job);
    onJobAdded(result);
    setCommand("");
    setUrl("");
  };

  return (
    <Box display="flex" gap={2} mb={2} flexWrap="wrap">
      <TextField
        label="OS Command"
        value={command}
        onChange={(e) => setCommand(e.target.value)}
      />
      <Button variant="contained" onClick={handleOsSubmit}>
        Run OS Job
      </Button>
      <TextField
        label="Crawl URL"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
      />
      <Button variant="contained" onClick={handleCrawlSubmit}>
        Run Crawl Job
      </Button>
      <Button variant="outlined" onClick={handleGenericJob}>
        Add Generic Job
      </Button>
    </Box>
  );
};

export default JobForm;
