// src/api/jobs.js
const API_URL = "http://localhost:5000";

// Tüm jobları getir
export async function getJobs() {
  const res = await fetch(`${API_URL}/jobs`);
  return res.json();
}

// Yeni OS job oluştur
export async function createOsJob(command) {
  const res = await fetch(`${API_URL}/job/os`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ command })
  });
  return res.json();
}

// Yeni Crawl job oluştur
export async function createCrawlJob(url) {
  const res = await fetch(`${API_URL}/job/crawl`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });
  return res.json();
}

// Genel job ekleme fonksiyonu (type ve command_or_url kullanır)
export async function addJob(job) {
  const res = await fetch(`${API_URL}/job`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(job)
  });
  return res.json();
}
