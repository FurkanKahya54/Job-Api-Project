import React, { useState, useEffect } from "react";
import JobForm from "./components/JobForm";
import JobList from "./components/JobList";
import { getJobs } from "./api/jobs";
import { Container, Typography } from "@mui/material";

function App() {
  const [jobs, setJobs] = useState([]);

  const fetchJobs = async () => {
    const data = await getJobs();
    setJobs(data);
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handleJobAdded = (newJob) => {
    fetchJobs(); // yeni job eklendiğinde listeyi güncelle
  };

  return (
    <Container>
      <Typography variant="h4" mt={2} mb={2}>Job Dashboard</Typography>
      <JobForm onJobAdded={handleJobAdded} />
      <JobList jobs={jobs} />
    </Container>
  );
}

export default App;
